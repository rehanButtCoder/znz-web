import React from 'react'
import CreateTask from '../../components/createTask/CreateTask'

const CreateATask = () => {
  return (
    <div>
        <CreateTask/>
    </div>
  )
}

export default CreateATask