import React from 'react'
import MyProposals from '../../components/myProposals/MyProposals'

const AllProposals = () => {
  return (
    <div>
        <MyProposals/>
    </div>
  )
}

export default AllProposals