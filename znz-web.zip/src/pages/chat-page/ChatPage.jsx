import React from 'react'
import Chat from '../../components/chat-box/Chat'
const ChatPage = () => {
  return (
    <div>
        <Chat/>
    </div>
  )
}

export default ChatPage