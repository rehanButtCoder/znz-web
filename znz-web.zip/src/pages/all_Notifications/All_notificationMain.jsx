import React from 'react';
import AllNotifications from '../../components/all Notifications/AllNotifications';

function AllnotificationMain() {
  return (
    <div>
      <AllNotifications/>
    </div>
  )
}

export default AllnotificationMain
