import React from 'react'
import ViewAllStudent from '../../components/viewAllStudent/ViewAllStudent'
const ViewStudents = () => {
  return (
    <div>
        <ViewAllStudent/>
    </div>
  )
}

export default ViewStudents