import React from 'react'
import { OrderDetail } from '../../components/oder-detail/OrderDetail'

const OrderDetailPage = () => {
  return (
    <div>
        <OrderDetail/>
    </div>
  )
}

export default OrderDetailPage