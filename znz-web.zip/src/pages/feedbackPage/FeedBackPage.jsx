import React from 'react'
import FeedBack from '../../components/feedback/FeedBack'
const FeedBackPage = () => {
  return (
    <React.Fragment>
        <FeedBack/>
    </React.Fragment>
  )
}

export default FeedBackPage