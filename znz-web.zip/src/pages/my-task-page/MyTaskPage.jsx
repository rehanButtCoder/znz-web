import React from 'react'
import MyTask from '../../components/my-task/MyTask'

const MyTaskPage = () => {
  return (
    <div>
        <MyTask/>
    </div>
  )
}

export default MyTaskPage