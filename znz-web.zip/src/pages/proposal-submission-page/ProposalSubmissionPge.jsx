import React from 'react'
import ProposalSubmissionComp from '../../components/proposal-submission/ProposalSubmissionComp'

const ProposalSubmissionPge = () => {
  return (
    <div>
        <ProposalSubmissionComp/>
    </div>
  )
}

export default ProposalSubmissionPge