import React from 'react'
// import Card from '../../components/cards/Card'
function TestPage() {
  return (
    <div>
      {/* <Card/> */}
    </div>
  )
}

export default TestPage
