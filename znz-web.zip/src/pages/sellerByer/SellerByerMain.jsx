import React from 'react';
import BeccomeSellerByer from '../../components/becomeSellerOrByer/BeccomeSellerByer';

function SellerByerMain() {
  return (
    <div>
      <BeccomeSellerByer/>
    </div>
  )
}

export default SellerByerMain
