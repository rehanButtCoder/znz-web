import React from 'react'
import AllMessage from '../../components/allMessages/AllMessage'
export default function AllMessageMain() {
  return (
    <div>
      <AllMessage/>
    </div>
  )
}
