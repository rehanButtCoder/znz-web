import React from 'react'
import JobForU from '../../components/jobForYou/JobForU'

const JobForYou = () => {
  return (
    <React.Fragment>
        <JobForU/>
    </React.Fragment>
  )
}

export default JobForYou