import React from 'react'
import './AllNotification.css'
import { Container } from 'react-bootstrap'

function AllNotifications() {
  return (
<Container className='main-c1'> 

      <div className='border rounded main-header-notifi'>
        <h2>All <span className='word-notifi'>Notifications</span></h2>
      </div>


      <div className='content-container-all-notific border rounded'>

        <div className='cntnt-user  '>
          <div className='img-c-left'><img src='/asserts/images/all-notification-sellerprofile/Avatar.png' width="50px" height="50px" alt="some" /></div>
          <div className='inner-desc-c-right'>
            <h4>Dennis Nedry</h4>
            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma Nemo
              enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut fugit, sed quia consequuntur ma</p>
            <p className='time-of-inner-user'>Last Wednesday at 9:42 AM</p>
          </div>
        </div>


        <div className='cntnt-user '>
          <div className='img-c-left'><img src='/asserts/images/all-notification-sellerprofile/Avatar.png' width="50px" height="50px" alt="some" /></div>
          <div className='inner-desc-c-right'>
            <h4>Dennis Nedry</h4>
            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma Nemo
              enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut fugit, sed quia consequuntur ma</p>
            <p className='time-of-inner-user'>Last Wednesday at 9:42 AM</p>
          </div>
        </div>

        <div className='cntnt-user '>
          <div className='img-c-left'><img src='/asserts/images/all-notification-sellerprofile/Avatar.png' width="50px" height="50px" alt="some" /></div>
          <div className='inner-desc-c-right'>
            <h4>Dennis Nedry</h4>
            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma Nemo
              enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut fugit, sed quia consequuntur ma</p>
            <p className='time-of-inner-user'>Last Wednesday at 9:42 AM</p>
          </div>
        </div>

        <div className='cntnt-user'>
          <div className='img-c-left'><img src='/asserts/images/all-notification-sellerprofile/Avatar.png' width="50px" height="50px" alt="some" /></div>
          <div className='inner-desc-c-right'>
            <h4>Dennis Nedry</h4>
            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma Nemo
              enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut fugit, sed quia consequuntur ma</p>
            <p className='time-of-inner-user'>Last Wednesday at 9:42 AM</p>
          </div>
        </div>

        <div className='cntnt-user '>
          <div className='img-c-left'><img src='/asserts/images/all-notification-sellerprofile/Avatar.png' width="50px" height="50px" alt="some" /></div>
          <div className='inner-desc-c-right'>
            <h4>Dennis Nedry</h4>
            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma Nemo
              enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut fugit, sed quia consequuntur ma</p>
            <p className='time-of-inner-user'>Last Wednesday at 9:42 AM</p>
          </div>
        </div>



        <div className='cntnt-user '>
          <div className='img-c-left'><img src='/asserts/images/all-notification-sellerprofile/Avatar.png' width="50px" height="50px" alt="some" /></div>
          <div className='inner-desc-c-right'>
            <h4>Dennis Nedry</h4>
            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma Nemo
              enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut fugit, sed quia consequuntur ma</p>
            <p className='time-of-inner-user'>Last Wednesday at 9:42 AM</p>
          </div>
        </div>
        <div className='cntnt-user '>
          <div className='img-c-left'><img src='/asserts/images/all-notification-sellerprofile/Avatar.png' width="50px" height="50px" alt="some" /></div>
          <div className='inner-desc-c-right'>
            <h4>Dennis Nedry</h4>
            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma Nemo
              enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut fugit, sed quia consequuntur ma</p>
            <p className='time-of-inner-user'>Last Wednesday at 9:42 AM</p>
          </div>
        </div>
        <div className='cntnt-user '>
          <div className='img-c-left'><img src='/asserts/images/all-notification-sellerprofile/Avatar.png' width="50px" height="50px" alt="some" /></div>
          <div className='inner-desc-c-right'>
            <h4>Dennis Nedry</h4>
            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur ma Nemo
              enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut fugit, sed quia consequuntur ma</p>
            <p className='time-of-inner-user'>Last Wednesday at 9:42 AM</p>
          </div>
        </div>



      </div>


    
    </Container>
  )
}

export default AllNotifications
