import React from "react";
const Loader = () => {
  return (
    <div className="ldsripple">
      <div></div>
      <div></div>
    </div>
  );
};

export default Loader;
