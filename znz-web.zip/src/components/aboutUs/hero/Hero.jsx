import React from 'react'

const Hero = () => {
  return (
    <div>Hero About</div>
  )
}

export default Hero