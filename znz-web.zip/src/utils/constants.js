// import React from 'react'
// import { useSelector } from "react-redux";

// const constants = () => {
//     const userData = useSelector((state) => state.user.userData);

//   return (
//     <div>constants</div>
//   )
// }

// export default constants
export const buyerRoleId = "64aee9587e73d38366c4905b"
export const sellerRoleId = "64aee9587e73d38366c4905a"