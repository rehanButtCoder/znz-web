export const convertToStringOfArray = (data) => {
    return data.map((item) => item.value);
  };